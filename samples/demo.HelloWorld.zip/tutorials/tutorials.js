//tutorials.js
/*  This library will add a set of tutorial elements to the sample application.  
    Once you are ready to develop on your own, simply remove this library. 
*/

//http://www.appmobi.com/documentation/hybridAPI.html

var TUTORIAL = 1;
var iResponses = 0;
var paramsObj
function loadTutorial(tutorialHTML)
{
	//Import tutorial HTML data
	paramsObj = new AppMobi.Device.RemoteDataParameters();
	paramsObj.url=AppMobi.webRoot+tutorialHTML + ".html";
	paramsObj.id="LoadingTutorial";
	paramsObj.method="GET";
	
	document.addEventListener("appMobi.device.remote.data", function(returnedEvent){
		
		if (returnedEvent.id=="LoadingTutorial")
		{
			
			if (returnedEvent.success==true)
			{ 
				document.getElementsByTagName("body")[0].innerHTML += returnedEvent.response; 
				//console.log(document.getElementsByTagName("body")[0].innerHTML);
			}
			else
			{ console.log("remote load: " +  returnedEvent.success) }
			
			aUX_Load();
			
		}
	}, false);
	
	AppMobi.device.getRemoteDataExt(paramsObj);
	
}


function loadAsyncScript(src, callback) {

	src = AppMobi.webRoot+src;
	var xhrObj = new XMLHttpRequest();
	xhrObj.onreadystatechange = function() { if (xhrObj.readyState != 4) { return; } 
		var myStr=xhrObj.responseText;
		//console.log(myStr);
		try{ eval(myStr); }
		
		catch(loadError){ alert("Error loading script "+src+"  "+loadError); }
		if (callback) callback(); 
		console.log("exit");
	};
	xhrObj.open('GET', src, true);
	xhrObj.send('');
}

//Global Variables
var deviceUUID ="";
var didcheckuser=null;
var rssObject;

var admob_vars = {
 pubid: 'a1499f014240b72', // publisher id
 bgcolor: 'FFFFFF', // background color (hex)
 text: '000000', // font-color (hex)
 ama: false, // set to true and retain comma for the AdMob Adaptive Ad Unit, a special ad type designed for PC sites accessed from the iPhone.  More info: http://developer.admob.com/wiki/IPhone#Web_Integration
 test: true // test mode, set to false to receive live ads
};


var onDeviceReady = function() {
	loadTutorial("tutorials/tutorialHTML");
	
	try {
		deviceUUID = AppMobi.device.uuid;
		if (deviceUUID.indexOf("emulated") != -1)
		{
			deviceUUID = "000000";
		}
		pushMobi.init({"userId":deviceUUID,"password":"password","email":"test@test.com"});
	} catch(err) { console.log("error setting up pushMobi in tutorials.js: " + err.message); }
	
	//start the XDK tour once
	if (AppMobi.cache.getCookie("XDKPreview")==undefined && AppMobi.device.uuid.indexOf("emulated") != -1)
	{
		AppMobi.cache.setCookie("XDKPreview","DONE",-1);
		startTour();
	}

	
};
document.addEventListener("appMobi.device.ready", onDeviceReady, false);