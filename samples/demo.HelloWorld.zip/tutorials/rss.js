/* RSS appSlice */

function objRSS(listener,rssURL)
{
    /* Properties */
    this.feedURL = rssURL;
    this.channels = new Array();
    

    /* Methods */
    this.open = function() {
        AppMobi.device.getRemoteData(this.feedURL,"GET", "","rssSuccess","rssFailure");
    };
    
    function parseRSS(listener, rssData)
    {
        //console.log(rssData);
        var outArr = new Array();
        
        parser=new DOMParser();
        xmlData=parser.parseFromString(rssData,"text/xml");
        if (rssData != null)
        { xmlData.alltext = rssData; }
        
        //for each channel
        for (var a=0;a<xmlData.getElementsByTagName("channel").length;a++)
        {
            var channel = xmlData.getElementsByTagName("channel")[a];
            var channelOutputObject = new Object();
            channelOutputObject.items = new Array();
            
            for (var b=0;b<channel.childNodes.length;b++)
            {
                if (channel.childNodes[b].nodeName == "item")
                {
                    var item = channel.childNodes[b];
                    var itemOutputObject = new Object();
                    for (var c=0;c<item.childNodes.length;c++)
                    {
                        try
                        {
                            if (item.childNodes[c].nodeName.indexOf("#")==-1)
                            {
                                if (item.childNodes[c].childNodes[0])
                                {
                                    eval("itemOutputObject."+item.childNodes[c].nodeName+"=item.childNodes[c].childNodes[0].nodeValue;");
                                    //console.log(item.childNodes[c].nodeName + "  " + eval("itemOutputObject."+item.childNodes[c].nodeName));
                                }
                            }
                        }catch(e){  }
                    }
                    channelOutputObject.items[channelOutputObject.items.length]=itemOutputObject;
                }
                else
                {
                    if (channel.childNodes[b].nodeName.indexOf("#")==-1)
                    {
                        //console.log(channel.childNodes[b].nodeName);
                        if (channel.childNodes[b].attributes.length>0)
                        {
                            try
                            {
                                eval("channelOutputObject."+channel.childNodes[b].nodeName+"= new Object();");
                                for (var c=0;c<channel.childNodes[b].attributes.length;c++)
                                {
                                    eval("channelOutputObject."+channel.childNodes[b].nodeName+".Attributes."+channel.childNodes[b].attributes[c].name+"=channel.childNodes[b].attributes[c].value;");
                                    //console.log(eval("channelOutputObject."+channel.childNodes[b].nodeName+".Attributes."+channel.childNodes[b].attributes[c].name));
                                }
                            }
                            catch(e) {}
                        
                        }
                        if (channel.childNodes[b].childNodes[0])
                        {
                            eval("channelOutputObject."+channel.childNodes[b].nodeName+"=channel.childNodes[b].childNodes[0].nodeValue;");
                            //console.log(eval("channelOutputObject."+channel.childNodes[b].nodeName));
                        }
                    }
                }

            
            }
            outArr[outArr.length] = channelOutputObject;
        }
        
        return outArr;
    
    }
   
   /* Event Listener */ 
   successEvent = new CustomEvent("rssSuccess");
   successEvent.subscribe(function(sender,evtArgs) {
        this.channels=parseRSS(listener,evtArgs.rssData);
        listener(this.channels);
   });
    
}

var successEvent=null;
function rssSuccess(data)
{
    //console.log("in rssSuccess");
    successEvent.fire(null,{rssData:data});

}

function rssFailure(data)
{
    //console.log("rssFailure: " + data);
}

var CustomEvent = function() {
	//name of the event
	this.eventName = arguments[0];
	var mEventName = this.eventName;

	//function to call on event fire
	var eventAction = null;

	//subscribe a function to the event
	this.subscribe = function(fn) {
		eventAction = fn;
	};

	//fire the event
	this.fire = function(sender, eventArgs) {
		//this.eventName = eventName2;
		if(eventAction != null) {
			eventAction(sender, eventArgs);
		}
		else {
			alert('There was no function subscribed to the ' + mEventName + ' event!');
		}
	};
};


//***************************

var channels = new Array();
function rssLoaded(arrChannels)
{ 
	//console.log("RSS Feed Loaded Successfully");
	channels=arrChannels;
	document.getElementById("divRSSTitle").innerHTML = channels[0].title;
	var bodyHTML = "";
	
	for (var x=0;x<channels[0].items.length;x++)
	{
		bodyHTML += "<hr/>";
		bodyHTML += "<b>"+channels[0].items[x].title+"</b><br/>";
		bodyHTML += channels[0].items[x].pubDate + "<br/>";
		bodyHTML += channels[0].items[x].description + "<br/>";
	}
	document.getElementById("divRSSText").innerHTML=bodyHTML;
}
