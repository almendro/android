function loadAsyncScript(src, callback) {

	var xhrObj = new XMLHttpRequest();
	xhrObj.onreadystatechange = function() { if (xhrObj.readyState != 4) { return; } 
	var myStr=xhrObj.responseText;
//	myStr="try{\n "+myStr+" \n}\n catch(e){alert('Error '+e);}";
	try{
	window.eval(myStr);
	}
	catch(loadError){alert("Error loading script "+src+"  "+loadError);}
	if (callback) callback(); 
	};
	xhrObj.open('GET', src, true);
	xhrObj.send('');
}