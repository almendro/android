// ----------------------------------
// INIT PUBNUB
// ----------------------------------
var pubnub = PUBNUB.init({
	publish_key   : 'pub-d29d55ad-32af-4c4e-860f-d592a3494119',
	subscribe_key : 'sub-b415cc54-ef64-11e0-9cd7-8d3cc5976928',
	ssl           : false,
	origin        : 'pubsub.pubnub.com'
});

// -------------------
// LISTEN FOR MESSAGES
// -------------------
pubnub.subscribe({
	channel  : "hello_world",
	callback : function(message) { console.log("in callback"); document.getElementById('chatWindow').innerHTML = message + "\r" + document.getElementById('chatWindow').innerHTML;		}
})


// ------------
// SEND MESSAGE
// ------------
var sendMessage = function(messageText) {
console.log(messageText);
console.log("in sendMessage");
	pubnub.publish({
		channel : "hello_world",
		message : messageText
	});
}



