//global variables
var podcastRSSURL="http://www.npr.org/rss/podcast.php?id=4499275";
var feedTimeout;

var iPortraitWidth=768;
var iLandscapeWidth=1024;

var previousXMLData;
var xmlhttp = null;
var boolDebounce = false;


function dataFailed(xmlData)
{
	AppMobi.notifications.alert(xmlData,"Podcast Failure","OK");
}
				
function dataLoaded(strRequestResponse)
{
	var parser=new DOMParser();
	xmlData=parser.parseFromString(strRequestResponse,"text/xml");
	xmlData.alltext = strRequestResponse; 
	
	if (xmlData != null) {previousXMLData = xmlData;} else {xmlData = previousXMLData;}

	if (xmlData!=null)
	{
		var outHTML = ""; 
		document.getElementById("podcastTitle").innerHTML = xmlData.getElementsByTagName("title")[0].childNodes[0].nodeValue;

		outHTML += "<ul>";

		var nodeList;
		nodeList = xmlData.getElementsByTagName("channel");
						  
		if (nodeList.length > 0)
		{
			for (var i=0; i<nodeList.length; i++)
			{
				if (nodeList.item(i).getElementsByTagName("item").length >= 1)
				{
					for (var ii=0; ii<nodeList.item(i).getElementsByTagName("item").length; ii++)
					{
						var selNode = nodeList.item(i).getElementsByTagName("item").item(ii);
						var strTitle = "";
						var strPodcastLink = "";
						var strPodcastMP3 = "";
						var strNodeIcon = "";
						
						for (var x=0;x<selNode.childNodes.length; x++)
						{
							if (selNode.childNodes[x].nodeName == "title")
							{
								strTitle = selNode.childNodes[x].childNodes[0].nodeValue;
							} 
							
							if (selNode.childNodes[x].nodeName == "enclosure")
							{
								strPodcastMP3 = selNode.childNodes[x].getAttribute("url");
							}  
							
							if (selNode.childNodes[x].nodeName == "link")
							{
								strPodcastLink = selNode.childNodes[x].childNodes[0].nodeValue;
							}       
						}
						outHTML += "<li><a href='javascript:;' onclick=\"playPodcast('" + strPodcastMP3 + "');\">";
						outHTML += strTitle;
						outHTML += "</a></li>";
						
					}
				}
			}
			outHTML += "</ul><br/><br/><br/>";
			document.getElementById("podcastEpisodes").innerHTML = outHTML
		}
	}
}

function playPodcast(podcastURL)
{
	try
	{
		if (boolDebounce == false)
		{
			boolDebounce = true;
		
			//load the podcast
			AppMobi.player.playPodcast(podcastURL);
			setTimeout("boolDebounce = false",5000);
		}
	}
	catch(e){ alert("error in playpodcast: " + e.message); }
}



//event handlers
document.addEventListener("appMobi.player.audio.stop",onPodcastComplete,false);
document.addEventListener("appMobi.player.audio.error",onPodcastError,false);

	
function loadPodcastData()
{
	
	AppMobi.device.getRemoteData(podcastRSSURL,"GET","","dataLoaded","dataFailed");
}




//*** Audio Code ******************

function onPodcastComplete()
{

}

function onPodcastError()
{}

