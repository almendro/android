/* XDK Online Help Library */

//This library provides functions used to explain what all the features of the XDK are IN the XDK from a particular application

var arrHelpDIVs = new Array();
function createHelp(uniqueID,passedHTML,top,left,passedStyle,boolUpperRight) 
{
	var XDKTopLevelBodyTag = window.parent.parent.document.getElementsByTagName("body")[0];
	if (window.parent.parent.document.getElementById(uniqueID) == null)
	{
		var closeTarget = AppMobi.webRoot + "tutorials/images/closeTarget.png";
		var newdiv = window.parent.document.createElement('div');
		newdiv.setAttribute("id",uniqueID);
		newdiv.setAttribute("trueleft",left);
		if (boolUpperRight)
		{
			newdiv.setAttribute("style","cursor:default;position:absolute;top:" + top + "px;left:" + (left+250) + "px;background-color:red;width:310px;display:none;");	
			newdiv.innerHTML = "<canvas id='canv"+uniqueID+"' style='position:absolute;top:0px;right:0px;height:60px;width:60px;'></canvas><div id='div"+uniqueID+"' style='position:absolute;top:50px;left:0px;width:250px;"+passedStyle+"'><img src='"+closeTarget+"' style='float:right;' />"+passedHTML+"</div>";

		}
		else
		{
			newdiv.setAttribute("style","cursor:default;position:absolute;top:" + top + "px;left:" + left + "px;display:none;");
			newdiv.innerHTML = "<canvas id='canv"+uniqueID+"' style='position:absolute;top:0px;left:0px;height:60px;width:60px;'></canvas><div id='div"+uniqueID+"' style='position:absolute;top:50px;left:50px;width:250px;"+passedStyle+"'><img src='"+closeTarget+"' style='float:right;' />"+passedHTML+"</div>";
		}
		
		newdiv.setAttribute("onclick",'this.style.display="none"; document.getElementById("emulator").contentWindow.document.getElementById("em-frm").contentWindow.showNextHelp();');  //change to gradual fade
		XDKTopLevelBodyTag.appendChild(newdiv);
		arrHelpDIVs[arrHelpDIVs.length]=uniqueID;
		
		
		//draw the line in canvas
		var canvas = window.parent.parent.document.getElementById("canv"+uniqueID);
		var context = canvas.getContext("2d");
		
		if (boolUpperRight)
		{
			context.beginPath();
			context.moveTo((canvas.width-30),20);
			context.lineTo(0, canvas.height);
			context.lineWidth=10;
			context.strokeStyle="#ff9900";
			context.lineCap = "round";
			context.stroke();
			
			//draw the circle in canvas
			context.beginPath();
			context.scale(1, 0.5);
			context.arc((canvas.width-30),30,30,0, 2 * Math.PI, false);
			context.lineWidth = 1;
			context.strokeStyle = "#ff9900";
			context.stroke();
			context.fillStyle = "#ff9900";
			context.fill();

		}
		else
		{
			context.beginPath();
			context.moveTo(30,20);
			context.lineTo(canvas.width, canvas.height);
			context.lineWidth=10;
			context.strokeStyle="#ff9900";
			context.lineCap = "round";
			context.stroke();
			
			//draw the circle in canvas
			context.beginPath();
			context.scale(1, 0.5);
			context.arc(30,30,30,0, 2 * Math.PI, false);
			context.lineWidth = 1;
			context.strokeStyle = "#ff9900";
			context.stroke();
			context.fillStyle = "#ff9900";
			context.fill();
		}
	
	}
}

var nextHelp = -1;
var timerControl;
function showNextHelp()
{
	console.log("in showNextHelp  " + nextHelp);
	clearTimeout(timerControl);
	if (nextHelp >= arrHelpDIVs.length)
	{
		destroyAllHelp();
	}
	var XDKTopLevelBodyTag = window.parent.parent.document;
	if (nextHelp >= 0)
	{
		XDKTopLevelBodyTag.getElementById(arrHelpDIVs[nextHelp]).style.display="none";
	}
	nextHelp = nextHelp + 1;
	
	//console.log(nextHelp);
	if (nextHelp < arrHelpDIVs.length)
	{
		console.log(arrHelpDIVs[nextHelp]);
		XDKTopLevelBodyTag.getElementById(arrHelpDIVs[nextHelp]).style.display="block";
		timerControl=setTimeout("showNextHelp();",6000);
	}
	else
	{
		destroyAllHelp();
	}
}


function destroyAllHelp() 
{
	try 
	{
		var XDKTopLevelBodyTag = window.parent.parent.document;
		for (var x=0;x<arrHelpDIVs.length;x++)
		{
			XDKTopLevelBodyTag.getElementById(arrHelpDIVs[x]).style.display = "none";
		}
		nextHelp = -1;
	} 
	catch(err) {  }
}


//position help despite screen resizing
window.parent.parent.document.getElementsByTagName("body")[0].onresize = function() {
	resizeHelp();
}


function resizeHelp()
{
	var windowWidth = window.parent.parent.innerWidth;
	if (windowWidth > 1195)
	{
		var XDKTopLevelBodyTag = window.parent.parent.document;
		for (var x=0;x<arrHelpDIVs.length;x++)
		{
			var helpDIV=XDKTopLevelBodyTag.getElementById(arrHelpDIVs[x]);
			var newLeft = helpDIV.getAttribute("trueLeft");
			newLeft = (newLeft/1) - ((1195 - (windowWidth/1) )/2);
			helpDIV.style.left = newLeft +"px";
		}
	}
	else
	{
		var XDKTopLevelBodyTag = window.parent.parent.document;
		for (var x=0;x<arrHelpDIVs.length;x++)
		{
			var helpDIV=XDKTopLevelBodyTag.getElementById(arrHelpDIVs[x]);
			helpDIV.style.left = helpDIV.getAttribute("trueLeft") +"px";
		}
	}
}

function startTour()
{
	destroyAllHelp();
	
	var passedStyle = "color:#000;font-family:arial;text-align:center;font-size:14pt;width:250px;background-color:#ff9900;padding:3px;border-radius:5px;";
	createHelp("divHelpStart","Click here to create a new project",22,155,passedStyle);
	createHelp("divHelpProject","Click here to view demo apps",15,315,passedStyle);
	createHelp("divHelpViewCode","Click here to view the root directory of the current application's source code",15,665,passedStyle);
	createHelp("divHelpTestAnywhere","Click here to test your application on an actual device",15,800,passedStyle);
	createHelp("divHelpBuild","Click here to build your application into a binary to submit it to an application store",15,885,passedStyle);
	createHelp("divHelpDocumentation","Click here to view custom API documentation",15,700,passedStyle,true);
	createHelp("divHelpDevices","Click here to preview an application on a variety of devices",75,605,passedStyle,true);
	createHelp("divHelpAcceleropmeter","Click here to test accelerometer enabled applications",170,605,passedStyle,true);
	createHelp("divHelpGeolocation","Click here to test geolocation enabled applications",410,605,passedStyle,true);
	createHelp("divHelpTest","Test your application immediately as you develop it",350,550,passedStyle);
	createHelp("divHelpCloudServices","Click in this column to integrate services like push messaging into your application",315,60,passedStyle);
	
	
	//account for XDK screen sizing
	resizeHelp();
	showNextHelp();
	
}