var map=""; //google maps object

//var YELP_KEY = "nz30aoBsMRQo9-uBrMtAzQ";
var YELP_KEY = "DUTj2mhHDeKUllw4CUUiNA"


function getYelpData() {

	AMUi.showMask();

	var suc=function(p)
	{
		var lat=p.coords.latitude;
		var lng=p.coords.longitude;
		
		searchYelp(lat,lng,"food","yelpCallback");

		/*
		var myLatlng = new google.maps.LatLng(lat, lng);
		var myOptions = {
		  zoom: 8,
		  center: myLatlng,
		  mapTypeId: google.maps.MapTypeId.ROADMAP
		}
		map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
		*/
	
	}
	var fail=function( ){
		alert("Error getting location");
	}
	try { AMUi.showMask(); } catch(e) {}
	AppMobi.geolocation.getCurrentPosition(suc,fail); 
	
}

function searchYelp(latitude, longitude, searchType, callbackFunction)
{
	AppMobi.device.getRemoteData('http://api.yelp.com/business_review_search?ywsid=' + YELP_KEY +'&term=' + escape(searchType) +'&lat=' + latitude + "&long=" + longitude,"GET","",callbackFunction,"errorCB");
}

function yelpCallback(data)
{
	try {
	
		var newContent = '<button onclick="getYelpData();">Find Food in your Area</button><br/>';
		
		data=JSON.parse(data);
		for (var x=0;x<data.businesses.length;x++)
		{
			//console.log(data.businesses[x].name);
			if (x<10)
			{
				newContent += "<li/>" + data.businesses[x].name + "(" + data.businesses[x].address1 + ")";
			}
		}

		AMUi.updateContentDiv("yelpWebservice",newContent);		
			
		AMUi.hideMask();
	
	} catch(e){ alert("error in searchYelpCB: " + e.message); AMUi.hideMask(); }
}


function errorCB(data)
{
  console.log ("GRD error "+data);
}

var marker="";
var barCoords;
